clear;
clc
folder_now = pwd;
addpath([folder_now, '/funs']);
addpath([folder_now, '/dataset/']);
addpath([folder_now, '/measure/']);
addpath([folder_now, '/missdataset/']);
percentDel = [0.1 0.3 0.5];
f=1;
for o=1:length(percentDel)
    dataname=["NGs"];
    for it_name = 1:length(dataname)
        load(strcat(dataname(it_name),'.mat'));
        load(dataname(it_name)+'_percentDel_'+num2str(percentDel(o))+'.mat')
        ind_folds = folds{f};
        clear folds
        if dataname(it_name)~="ORL" && dataname(it_name)~="scene15" && dataname(it_name)~="UCI" && dataname(it_name)~="still-2"&& dataname(it_name)~="VGGFace2-50"
            gt=truelabel{1};
            X=data;%dv by n
            clear truelabel data
        end
        if dataname(it_name)=="VGGFace2-50"
            gt=Y;
            clear Y
            for i =1:length(X)
                X{i}=X{i}';
            end
        end
        if size(gt,1) ==1
            gt=gt';
        end
        V=length(X);
        N = size(X{1},2);% number of data poin
        cls_num=length(unique(gt));
        
        numanchor=[cls_num 2*cls_num 3*cls_num];%cls_num 2*cls_num 3*cls_num 4*cls_num 5*cls_num 6*cls_num 7*cls_num
        alpha=[ 0.00001 0.0001  0.001 0.01 0.1 1 10   ];%0.00001 0.0001  0.001 0.01 0.1 1 10  
        beta=[0.00001 0.0001  0.001 0.01 0.1 1 10   ];%0.00001 0.0001  0.001 0.01 0.1 1 10  
        gamma=[ 0.00001 0.0001  0.001 0.01 0.1 1 10   ];%0.00001 0.0001  0.001 0.01 0.1 1 10  
        delta=[  0.01 0.1  1  10];
        bestacc=0;
        %normalized X
        for i=1:V
            X{i} = X{i}./repmat( max(1e-12*ones(1,N),sqrt(sum(X{i}.^2,1))),size(X{i},1),1);
        end
        
        for j=1:length(numanchor)
            parfor iv = 1:V
                rng(5489,'twister');
                Xtemp = X{iv};
                ind_0 = find(ind_folds(:,iv) == 0);
                ind_1 = find(ind_folds(:,iv) == 1);
                Xtemp(:,ind_0) = 0;    % 缺失视角�?0
                X_incomplete{iv} = Xtemp;         % �?列一个样�?
                % ------------- 构�?�缺失视角的索引矩阵 ----------- %
                linshi_M = eye(size(Xtemp,2));
                linshi_M(:,ind_1) = [];
                M{iv} = linshi_M';
                Ne(iv) = length(ind_0);
                % ---------- 初始锚� �� ----------- %
                Xtemp(:,ind_0) = [];
                [~, H{iv}] = litekmeans( Xtemp',numanchor(j),'MaxIter', 100,'Replicates',10);
                A{iv}=H{iv}';
            end
            
            for i=1:length(alpha)
                for k=1:length(beta)
                    for m=1:length(gamma)
                        
                        
                        for n=1:length(delta)
                            fprintf('params:\tnumanchor=%d\t\talpha=%f\tbeta=%f\n',numanchor(j),alpha(i),beta(k));
                            tic;
                            
                            % Core part of this code (LMVSC)
                            [labels] = LLRR_HLR(X_incomplete,M,Ne,gt,A,alpha(i),beta(k),gamma(m),delta(n));
                            
                            % Performance evaluation of clustering result
                            result =  ClusteringMeasure(gt, labels);
                            t=toc;
                            if result(1)>bestacc
                                bestacc=result(1);
                                dlmwrite('result/best_'+dataname(it_name)+num2str(percentDel(o))+'.txt',[numanchor(j)  alpha(i) beta(k) gamma(m) delta(n) result t],'-append','delimiter','\t','newline','pc');
                            end
                            fprintf('result:\t%12.6f %12.6f %12.6f %12.6f %12.6f %12.6f %12.6f\n',[result t]);
                            
                            % Write the evaluation results to a text file
                            dlmwrite('result/refertopara_'+dataname(it_name)+num2str(percentDel(o))+'.txt',[numanchor(j)  alpha(i) beta(k) gamma(m) delta(n) result t],'-append','delimiter','\t','newline','pc');
                        end
                    end
                end
            end
        end
    end
end