clear;
clc
folder_now = pwd;
addpath([folder_now, '/funs']);
addpath([folder_now, '/dataset/']);
addpath([folder_now, '/measure/']);
addpath([folder_now, '/missdataset/']);
percentDel = [0.1 0.3 0.5];
f=1;
for o=1:length(percentDel)
    dataname=[ "NGs"];%"BBCSport","HW","MSRCv1","ORL","100leaves","CCV"
    for it_name = 1:length(dataname)
        load(strcat(dataname(it_name),'.mat'));
        load(dataname(it_name)+'_percentDel_'+num2str(percentDel(o))+'.mat')
        ind_folds = folds{f};
        clear folds
        if dataname(it_name)~="ORL" && dataname(it_name)~="scene15" && dataname(it_name)~="UCI" && dataname(it_name)~="still-2"&& dataname(it_name)~="VGGFace2-50"
            gt=truelabel{1};
            X=data;%dv by n
            clear truelabel data
        end
        if dataname(it_name)=="VGGFace2-50"
            gt=Y;
            clear Y
            for i =1:length(X)
                X{i}=X{i}';
            end
        end
        if size(gt,1) ==1
            gt=gt';
        end
        V=length(X);
        N = size(X{1},2);% number of data poin
        cls_num=length(unique(gt));
        if percentDel(o)==0.1
            if dataname(it_name)=="MSRCv1"
                numanchor=2*cls_num; alpha=0.001;beta=0.001;gamma=0.001;delta=1;
            elseif dataname(it_name)== "NGs"
                numanchor=2*cls_num; alpha=0.01;beta=0.01;gamma=0.01;delta=1;
            elseif dataname(it_name)== "HW"
                numanchor=3*cls_num; alpha=0.01;beta=0.001;gamma=0.001;delta=0.1;
            elseif dataname(it_name)== "BBCSport"
               numanchor=2*cls_num; alpha=0.01;beta=0.0001;gamma=0.001;delta=1;
            elseif dataname(it_name)== "scene15"
                numanchor=2*cls_num; alpha=0.1;beta=0.001;gamma=1;delta=0.05;
            elseif dataname(it_name)== "Aloi-100"
                numanchor=cls_num; alpha=0.001;beta=0.0001;gamma=1;delta=0.1;
            end
        elseif percentDel(o)==0.3
            if dataname(it_name)=="MSRCv1"
                numanchor=cls_num; alpha=0.01;beta=0.1;gamma=0.001;delta=1;
            elseif dataname(it_name)== "NGs"
                numanchor=cls_num; alpha=1;beta=0.1;gamma=0.01;delta=0.1;
            elseif dataname(it_name)== "HW"
                numanchor=4*cls_num; alpha=0.01;beta=0.001;gamma=0.001;delta=0.1;
            elseif dataname(it_name)== "BBCSport"
                numanchor=cls_num; alpha=0.001;beta=0.001;gamma=0.001;delta=1;
            elseif dataname(it_name)== "scene15"
                numanchor=2*cls_num; alpha=0.1;beta=0.001;gamma=0.6;delta=0.1;
            elseif dataname(it_name)== "Aloi-100"
                numanchor=cls_num; alpha=0.1;beta=0.001;gamma=10;delta=0.1;
            end
        elseif percentDel(o)==0.5
            if dataname(it_name)=="MSRCv1"
                numanchor=cls_num; alpha=0.01;beta=0.001;gamma=0.001;delta=1;
            elseif dataname(it_name)==  "NGs"
                numanchor=cls_num; alpha=0.001;beta=0.001;gamma=0.001;delta=1;
            elseif dataname(it_name)== "HW"
                numanchor=2*cls_num; alpha=0.01;beta=0.001;gamma=0.001;delta=0.1;
            elseif dataname(it_name)== "BBCSport"
                numanchor=cls_num; alpha=0.001;beta=1;gamma=0.001;delta=1;
            elseif dataname(it_name)== "scene15"
                numanchor=2*cls_num; alpha=0.1;beta=0.001;gamma=0.5;delta=0.1;
            elseif dataname(it_name)== "Aloi-100"
                numanchor=cls_num; alpha=0.1;beta=0.001;gamma=10;delta=0.1;
            end
        end
        
        
        
        for i=1:V
            X{i} = X{i}./repmat( max(1e-12*ones(1,N),sqrt(sum(X{i}.^2,1))),size(X{i},1),1);
        end
        parfor iv = 1:V
            rng(5489,'twister');
            Xtemp = X{iv};
            ind_0 = find(ind_folds(:,iv) == 0);
            ind_1 = find(ind_folds(:,iv) == 1);
            Xtemp(:,ind_0) = 0;    % 缺失视角�?0
            X_incomplete{iv} = Xtemp;         % �?列一个样�?
            % ------------- 构�?�缺失视角的索引矩阵 ----------- %
            linshi_M = eye(size(Xtemp,2));
            linshi_M(:,ind_1) = [];
            M{iv} = linshi_M';
            Ne(iv) = length(ind_0);
            % ---------- 初始锚� �� ----------- %
            Xtemp(:,ind_0) = [];
            [~, H{iv}] = litekmeans( Xtemp',numanchor,'MaxIter', 100,'Replicates',10);
            A{iv}=H{iv}';
        end
        for j=1:10
            tic;   
            % Core part of this code (LMVSC)
            [labels] = LLRR_HLR(X_incomplete,M,Ne,gt,A,alpha,beta ,gamma ,delta);         
            % Performance evaluation of clustering result
            score(j,:) =  ClusteringMeasure(gt, labels)
            t(j,:)=toc;
        end
        clear X_incomplete M Ne A
        re_mean = mean(score);
        re_std = std(score);
        re_t=mean(t);
        save('result_IMLLRR_'+dataname(it_name)+num2str(percentDel(o))+'.mat','re_mean','re_std','re_t')
        
        % Write the evaluation results to a text file
        
    end
end
