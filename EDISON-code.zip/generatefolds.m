clear
clc
folder_now = pwd;
addpath([folder_now, '/funs']);
addpath([folder_now, '/dataset/']);

dataname=[ "Caltech101-all"];%"BBCSport","HW","MSRCv1","ORL","100leaves","CCV"
for it_name = 1:length(dataname)
    load(strcat(dataname(it_name),'.mat'));
    if dataname(it_name)~="ORL" && dataname(it_name)~="scene15" && dataname(it_name)~="UCI" && dataname(it_name)~="still-2"&& dataname(it_name)~="VGGFace2-50"
        gt=truelabel{1};
        X=data;%dv by n
    end
    if dataname(it_name)=="VGGFace2-50"
        gt=Y;
        for i =1:length(X)
            X{i}=X{i}';
        end
    end
    if size(gt,1) ==1
        gt=gt';
    end
    V=length(X);
    N = size(X{1},2);% number of data poin

    incp = [0.1 0.3 0.5 0.7];
    
    for i =1:length(incp)
        for j=1:10
            folds{j} = splitDigitData(N,V, incp(i));
        end
        save('missdataset\'+dataname(it_name)+'_percentDel_'+num2str(incp(i))+'.mat','folds')
        clear folds
    end
end
