function y = rank_fun_derivative(x,k)
% temp=a*exp(x/a).*((x+exp(-x/a)).^2);%exp(1)����Ȼ����e
% y=(x+a)./temp;
% y=(4*k)./(exp(2*k*x)+2+exp(-2*k*x
y=k*2/(pi^0.5).*exp(-(k*x).^2);
end
