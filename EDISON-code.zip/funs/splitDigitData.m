function [ splitInd ] = splitDigitData(N,M, inCP)
%SPLITDIGITDATA Summary of this function goes here
%   Detailed explanation goes here
% This code is used for constructing incomplete folds, i.e., index of missing views
% ind:
% inCP: ȱʧ��
% [N, M]  = size(ind);% N Ϊ�������� MΪ��ͼ��
% splitInd = ones(size(ind));
splitInd = ones(N,M);
indCell = cell(M,1);
delNum = floor(N * inCP); % ȱʧ����
% ��������ȱʧ
for i=1:M
    indCell{i} = randperm(N);
    splitInd(indCell{i}(1:delNum),i) = 0;
end
counter = ones(M,1)*delNum + 1;
% ȷ��ÿ������������һ����ͼ
while 1
    zerosInd = find(sum(splitInd,2)==0);
    if size(zerosInd,1) == 0
        break;
    else
        i = randi(M);
        splitInd(zerosInd(1),i) = 1;
        if(counter(i)<=N)
            splitInd(indCell{i}(counter(i)),i) = 0;
            counter(i) = counter(i) + 1;
        end
    end
end


